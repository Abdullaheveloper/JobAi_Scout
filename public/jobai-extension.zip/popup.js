const SUPABASE_URL = "https://okppdziaslsitmoqduqg.supabase.co";
const ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9rcHBkemlhc2xzaXRtb3FkdXFnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI5NzE3MTUsImV4cCI6MjA4ODU0NzcxNX0.yAFcwtZL8P2W-gN8ZyBik_CSA8c84cgBo9qJYouvPkc";
const TRACK_USAGE_URL = `${SUPABASE_URL}/functions/v1/track-extension-usage`;
const SECURITY_ALERT_URL = `${SUPABASE_URL}/functions/v1/security-alert`;
const TRACK_APPLIED_URL = `${SUPABASE_URL}/functions/v1/track-applied-job`;

const $ = (id) => document.getElementById(id);
const setStatus = (msg, err=false) => { const s=$("status"); s.textContent=msg||""; s.className="status"+(err?" err":""); };
const FIELD_LABELS = {
  email: "Email address",
  phone: "Phone number",
  first_name: "First name",
  last_name: "Last name",
  full_name: "Full name",
  linkedin: "LinkedIn URL",
  github: "GitHub URL",
  portfolio: "Portfolio URL",
  location: "Location",
  company: "Current company",
  experience: "Years of experience",
  summary: "Profile summary / bio",
  skills: "Skills",
  salary: "Expected salary",
};

async function api(path, opts={}) {
  const headers = { "Content-Type": "application/json", "apikey": ANON_KEY, ...(opts.headers||{}) };
  const res = await fetch(`${SUPABASE_URL}${path}`, { ...opts, headers });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error_description || json.msg || json.error || `HTTP ${res.status}`);
  return json;
}

async function signIn(email, password) {
  const data = await api("/auth/v1/token?grant_type=password", {
    method: "POST", body: JSON.stringify({ email, password }),
  });
  const session = {
    access_token: data.access_token,
    refresh_token: data.refresh_token,
    expires_at: Math.floor(Date.now()/1000) + (data.expires_in||3600),
    user: data.user,
  };
  await chrome.storage.local.set({ session });
  return session;
}

function parseAuthCallback(url) {
  const parsed = new URL(url);
  const params = new URLSearchParams(parsed.hash.slice(1));
  parsed.searchParams.forEach((value, key) => params.set(key, value));
  if (params.get("error") || params.get("error_description")) {
    throw new Error(params.get("error_description") || params.get("error") || "Google login failed");
  }
  const accessToken = params.get("access_token");
  const refreshToken = params.get("refresh_token");
  if (!accessToken || !refreshToken) throw new Error("Google login did not return a session");
  return {
    access_token: accessToken,
    refresh_token: refreshToken,
    expires_at: Math.floor(Date.now() / 1000) + Number(params.get("expires_in") || 3600),
  };
}

async function fetchAuthUser(accessToken) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { "apikey": ANON_KEY, "Authorization": `Bearer ${accessToken}` },
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error_description || json.msg || json.error || "Could not load Google user");
  return json;
}

async function signInWithGoogle() {
  if (!chrome?.identity?.getRedirectURL || !chrome?.identity?.launchWebAuthFlow) {
    throw new Error("Google login needs the Chrome identity permission. Reload the unpacked extension from chrome://extensions, or sign in with email and password.");
  }
  const redirectUrl = chrome.identity.getRedirectURL();
  const authUrl = `${SUPABASE_URL}/auth/v1/authorize?provider=google&redirect_to=${encodeURIComponent(redirectUrl)}`;
  const callbackUrl = await new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow({ url: authUrl, interactive: true }, (responseUrl) => {
      const err = chrome.runtime.lastError;
      if (err) reject(new Error(err.message));
      else if (!responseUrl) reject(new Error("Google login was cancelled"));
      else resolve(responseUrl);
    });
  });
  const session = parseAuthCallback(callbackUrl);
  session.user = await fetchAuthUser(session.access_token);
  await chrome.storage.local.set({ session });
  return session;
}

async function refreshIfNeeded() {
  const { session } = await chrome.storage.local.get("session");
  if (!session) return null;
  if (session.expires_at - 60 > Math.floor(Date.now()/1000)) return session;
  try {
    const data = await api("/auth/v1/token?grant_type=refresh_token", {
      method: "POST", body: JSON.stringify({ refresh_token: session.refresh_token }),
    });
    const next = { access_token:data.access_token, refresh_token:data.refresh_token,
      expires_at: Math.floor(Date.now()/1000)+(data.expires_in||3600), user:data.user };
    await chrome.storage.local.set({ session: next });
    return next;
  } catch { await chrome.storage.local.remove("session"); return null; }
}

async function fetchProfile(session) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/profiles?user_id=eq.${session.user.id}&select=full_name,email,phone,location,linkedin_url,github_url,experience_years,skills,desired_roles,cv_summary,bio`, {
    headers: { "apikey": ANON_KEY, "Authorization": `Bearer ${session.access_token}` },
  });
  const arr = await res.json();
  if (!res.ok) throw new Error(arr.message || arr.error || `Profile load failed: HTTP ${res.status}`);
  return Array.isArray(arr) && arr[0] ? arr[0] : null;
}

function renderProfile(session, p) {
  $("loginGate").style.display = "none";
  $("profile").style.display = "block";
  $("fillBtn").style.display = "block";
  $("logoutBtn").style.display = "block";
  const skills = Array.isArray(p?.skills) ? p.skills.join(", ") : "—";
  $("profile").innerHTML = `
    <div class="row"><span>Signed in</span><span>${session.user.email}</span></div>
    <div class="row"><span>Name</span><span>${p?.full_name || "—"}</span></div>
    <div class="row"><span>Phone</span><span>${p?.phone || "—"}</span></div>
    <div class="row"><span>Location</span><span>${p?.location || "—"}</span></div>
    <div class="row"><span>Skills</span><span title="${skills}">${skills}</span></div>
  `;
}

async function loadAndRenderProfile(session) {
  const profile = await fetchProfile(session);
  await chrome.storage.local.set({ profile });
  renderProfile(session, profile);
  setStatus(profile ? "Profile loaded" : "Signed in, but profile is empty", !profile);
  return profile;
}

function showLogin() {
  $("loginGate").style.display = "block";
  $("profile").style.display = "none";
  $("fillBtn").style.display = "none";
  $("retryBtn").style.display = "none";
  $("logoutBtn").style.display = "none";
  $("mismatch").style.display = "none";
  $("missingFields").style.display = "none";
}

function showMissingFields(missing = []) {
  const box = $("missingFields");
  const unique = [...new Set(missing)].filter(Boolean);
  if (!unique.length) {
    box.style.display = "none";
    box.innerHTML = "";
    return;
  }
  const items = unique
    .map((key) => `<li>${FIELD_LABELS[key] || key}</li>`)
    .join("");
  box.style.display = "block";
  box.innerHTML = `<strong>Missing from your JobAI profile</strong>These fields were found on this form but could not be filled:<ul>${items}</ul>`;
}

$("loginBtn").addEventListener("click", async () => {
  const email = $("emailInput").value.trim().toLowerCase();
  const password = $("passInput").value;
  if (!email || !password) { setStatus("Enter email and password", true); return; }
  setStatus("Signing in…");
  try {
    const session = await signIn(email, password);
    const profile = await fetchProfile(session);
    await chrome.storage.local.set({ profile });
    renderProfile(session, profile);
    setStatus("Signed in ✓");
  } catch (e) { setStatus(e.message || "Login failed", true); }
});

$("googleLoginBtn").addEventListener("click", async () => {
  setStatus("Opening Google login...");
  try {
    const session = await signInWithGoogle();
    const profile = await fetchProfile(session);
    await chrome.storage.local.set({ profile });
    renderProfile(session, profile);
    setStatus("Signed in with Google");
  } catch (e) { setStatus(e.message || "Google login failed", true); }
});

if (!chrome?.identity?.getRedirectURL || !chrome?.identity?.launchWebAuthFlow) {
  $("googleLoginBtn").disabled = true;
  $("googleLoginBtn").title = "Reload the extension after granting the identity permission.";
}

$("logoutBtn").addEventListener("click", async () => {
  await chrome.storage.local.remove(["session", "profile"]);
  showLogin(); setStatus("");
});

async function runFill() {
  $("mismatch").style.display = "none";
  showMissingFields([]);
  $("retryBtn").style.display = "none";
  const session = await refreshIfNeeded();
  if (!session) { showLogin(); setStatus("Please sign in", true); return; }
  const { profile } = await chrome.storage.local.get("profile");
  if (!profile) { setStatus("Profile not loaded", true); return; }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  const platform = (() => { try { return new URL(tab.url).hostname; } catch { return ""; } })();

  // Ensure content script is injected (works on any URL)
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: ["content.js"] });
  } catch {}

  // Step 1: detect email on page
  let detected = "";
  try {
    const r = await chrome.tabs.sendMessage(tab.id, { type: "DETECT_EMAIL" });
    detected = (r?.email || "").toLowerCase();
  } catch { setStatus("Cannot access this page (try a regular http/https tab)", true); return; }

  const userEmail = (session.user.email || "").toLowerCase();
  if (detected && detected !== userEmail) {
    // Mismatch: alert + block
    $("mismatch").style.display = "block";
    $("mismatch").textContent = `⚠️ Email mismatch. Page email "${detected}" does not match your account "${userEmail}". Auto-fill blocked.`;
    $("retryBtn").style.display = "block";
    setStatus("Verification failed", true);
    fetch(SECURITY_ALERT_URL, {
      method: "POST",
      headers: { "Content-Type":"application/json", "apikey": ANON_KEY, "Authorization": `Bearer ${session.access_token}` },
      body: JSON.stringify({ attempted_email: detected, page_url: tab.url, platform }),
    }).catch(() => {});
    return;
  }

  // Step 2: fill
  const res = await chrome.tabs.sendMessage(tab.id, { type: "FILL_FORM", profile });
  showMissingFields(res?.missing || []);
  setStatus(res?.count ? `Filled ${res.count} field(s) ✓` : (res?.missing?.length ? "Some profile fields are missing" : "No matching fields found"), Boolean(!res?.count && res?.missing?.length));
  // analytics
  fetch(TRACK_USAGE_URL, {
    method:"POST", headers:{ "Content-Type":"application/json","apikey":ANON_KEY },
    body: JSON.stringify({ email: userEmail, fields: res?.fields||[], page_url: res?.url||tab.url||"" }),
  }).catch(()=>{});
  // arm submit tracker
  chrome.tabs.sendMessage(tab.id, { type: "ARM_SUBMIT_TRACKER" }).catch(()=>{});
}

$("fillBtn").addEventListener("click", runFill);
$("retryBtn").addEventListener("click", runFill);

// Listen for application submitted from content script
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "APPLICATION_SUBMITTED") {
    refreshIfNeeded().then((session) => {
      if (!session) return;
      const payload = { ...msg.payload, status: "applied" };
      fetch(TRACK_APPLIED_URL, {
        method:"POST",
        headers:{ "Content-Type":"application/json","apikey":ANON_KEY,"Authorization":`Bearer ${session.access_token}` },
        body: JSON.stringify(payload),
      }).catch(()=>{});
    });
  }
});

(async () => {
  const session = await refreshIfNeeded();
  if (session) {
    let { profile } = await chrome.storage.local.get("profile");
    if (!profile) { profile = await fetchProfile(session); await chrome.storage.local.set({ profile }); }
    renderProfile(session, profile);
  } else {
    showLogin();
  }
})();
